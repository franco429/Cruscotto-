CRUSCOTTO LOCAL OPENER - VERSIONE COMPATIBILE
============================================

🎯 MASSIMA COMPATIBILITÀ WINDOWS
Questa versione è ottimizzata per funzionare su TUTTI i sistemi Windows.

📋 CONTENUTO PACCHETTO
✅ local-opener-x64.exe (Windows moderni)
❌ x86 non disponibile  
❌ legacy non disponibile
✅ start.bat (launcher automatico)

🚀 ISTRUZIONI SEMPLICI
1. Estrai TUTTI i file in una cartella
2. Esegui "start.bat" come AMMINISTRATORE
3. Il sistema sceglierà automaticamente la versione giusta
4. Torna al browser Cruscotto

⚠️ IMPORTANTE
- Esegui SEMPRE come amministratore
- Aggiungi eccezione antivirus se richiesto
- La porta 17654 deve essere libera

🔧 SE start.bat NON FUNZIONA
Prova in questo ordine:
1. local-opener-x64.exe (Windows 10/11)
2. local-opener-x86.exe (Windows 7/8) 
3. local-opener-x64-legacy.exe (ultimo tentativo)

📞 SUPPORTO: https://cruscotto-sgi.onrender.com
